# Reservaties – Epic 3 (Frontend + Node.js + MySQL via XAMPP)

Deze map gebruikt **MySQL** (XAMPP) als database, zodat je alles kunt zien in **phpMyAdmin**.

## Structuur

- `frontend/`
  - `index.html` – jouw UI, spreekt met de API via `/api/...`
- `backend/`
  - `server.js`         – Node.js/Express API (verbindt met MySQL)
  - `package.json`
  - `mysql-schema.sql`  – SQL script om in phpMyAdmin uit te voeren

## Stappenplan

1. Start XAMPP en zet **Apache** en **MySQL** aan.
2. Ga naar **phpMyAdmin** (meestal via http://localhost/phpmyadmin).
3. Ga naar tabje **SQL** en plak de inhoud van `backend/mysql-schema.sql`.
   - Klik op **Uitvoeren**. Hierdoor wordt database `epic3` + tabellen gemaakt.

4. Open een terminal in de `backend` map en installeer Node dependencies:

```bash
cd backend
npm install
```

5. Start de Node server:

```bash
npm start
```

6. Open in je browser:

- http://localhost:3000  → frontend
- http://localhost:3000/api/health → check API
- http://localhost/phpmyadmin → bekijk database `epic3` met tabellen `products` en `reservations`.

Nu kun je reserveringen maken in de UI en ze live zien verschijnen in phpMyAdmin.
